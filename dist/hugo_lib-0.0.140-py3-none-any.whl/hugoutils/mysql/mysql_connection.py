from contextlib import closing
from datetime import datetime, timezone
import functools
import io
import json
import re
import time

from botocore.exceptions import ClientError
from mysql.connector import pooling
from sshtunnel import SSHTunnelForwarder
import boto3
import mysql.connector
import paramiko

from hugoutils.mysql.response import (
    AuroraV1Response,
    AuroraV2Response,
    DuplicateKeyException,
    QueryResponseInterface,
    RdsException,
    RdsResponse,
)
from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger("MysqlConnection")


def retry_aurora_serverless(
    max_attempts=8,
    initial_interval=5,
    backoff_rate=1,
):
    def decorate_retry_aurora_serverless(func):
        @functools.wraps(func)
        def wrapper_retry_aurora_serverless(*args, **kwargs):
            attempt = 0
            delay = initial_interval
            while attempt < max_attempts:
                attempt += 1
                try:
                    return func(*args, **kwargs)
                except ClientError as ce:
                    if attempt >= max_attempts:
                        raise ce

                    error_code = ce.response.get("Error").get("Code")
                    error_msg = ce.response.get("Error").get("Message")
                    if (
                        error_code == "BadRequestException"
                        and "Communications link failure" in error_msg
                    ):
                        # Aurora serverless is waking up
                        logger.info(f"Sleeping {delay} secs, waiting RDS connection")
                        time.sleep(delay)
                        delay = delay * backoff_rate
                    else:
                        raise ce

            # This exception should never get raised as if the attempts are reached we throw the exception
            raise Exception(f"Failed to execute {kwargs}")

        return wrapper_retry_aurora_serverless

    return decorate_retry_aurora_serverless


class AuroraV1:
    def __init__(
        self, resource_arn, secret_arn, database, boto_profile=None, region=None
    ):
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)
        # rds-data api with mysql does not work in localstack
        # aurora v1 is skipped in the deployment script
        self.rds_client = self.boto_session.client("rds-data")

        self.connection_params = {
            "resourceArn": resource_arn,
            "secretArn": secret_arn,
        }
        self.db_params = {
            "database": database,
        }

    @staticmethod
    def __make_params(parameter_dict):
        params_list = []
        for name, value in parameter_dict.items():
            # if not value: can be true if value is 0, None, False.
            # But for 0 it should be Long value, and False it should be boolean value.
            # So we have to check these conditions first and then check null condition
            if isinstance(value, bool):
                descriptor = "booleanValue"
            elif isinstance(value, str):
                descriptor = "stringValue"
            elif isinstance(value, int):
                descriptor = "longValue"
            elif isinstance(value, float):
                descriptor = "doubleValue"
            elif isinstance(value, datetime):
                descriptor = "stringValue"
                if (
                    value.tzinfo is not None
                    and value.tzinfo.utcoffset(value) is not None
                ):
                    value = value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
                else:
                    value = value.isoformat("T", "seconds")
            elif not value:
                descriptor = "isNull"
                value = True
            else:
                descriptor = "stringValue"
            params_list.append({"name": name, "value": {descriptor: value}})
        return params_list

    @retry_aurora_serverless()
    def __execute_statement(self, *args, **kwargs):
        params = {**self.connection_params, **self.db_params, **kwargs}
        # logger.debug(f"__execute_statement: [{params}]")
        return self.rds_client.execute_statement(**params)

    @retry_aurora_serverless()
    def __begin_transaction(self, *args, **kwargs):
        params = {
            **self.connection_params,
            **self.db_params,
            **kwargs,
        }
        logger.debug(f"__begin_transaction: [{params}]")
        return self.rds_client.begin_transaction(**params)

    @retry_aurora_serverless()
    def __commit_transaction(self, *args, **kwargs):
        params = {**self.connection_params, **kwargs}
        logger.debug(f"__commit_transaction: [{params}]")
        return self.rds_client.commit_transaction(**params)

    @retry_aurora_serverless()
    def __rollback_transaction(self, *args, **kwargs):
        params = {**self.connection_params, **kwargs}
        logger.debug(f"__rollback_transaction: [{params}]")
        return self.rds_client.rollback_transaction(**params)

    def query(self, sql, params=None, min_max_columns=None):
        execution_params = {"sql": sql, "includeResultMetadata": True}
        if params:
            execution_params["parameters"] = AuroraV1.__make_params(params)

        response = self.__execute_statement(**execution_params)
        return RdsResponse(AuroraV1Response(response), min_max_columns)

    def mutate(self, sql, params=None):
        transaction_id = self.__begin_transaction().get("transactionId")

        try:
            execution_params = {
                "sql": sql,
                "transactionId": transaction_id,
            }
            if params:
                execution_params["parameters"] = AuroraV1.__make_params(params)

            self.__execute_statement(**execution_params)
            commit_params = {"transactionId": transaction_id}
            response = self.__commit_transaction(**commit_params)
        except ClientError as ce:
            logger.exception(f"Error in executing mutation with SQL {sql} rolling back")
            rollback_params = {"transactionId": transaction_id}
            self.__rollback_transaction(**rollback_params)

            error_code = ce.response.get("Error").get("Code")
            error_msg = ce.response.get("Error").get("Message")
            if error_code == "BadRequestException" and "Duplicate entry" in error_msg:
                raise DuplicateKeyException(ce)

            raise ce

        return RdsResponse(AuroraV1Response(response))

    def batch_mutate(self, sql, params=None):
        transaction_id = self.__begin_transaction().get("transactionId")
        try:
            for i in range(len(sql)):
                execution_params = {"sql": sql[i], "transactionId": transaction_id}
                if params[i]:
                    execution_params["parameters"] = AuroraV1.__make_params(params[i])
                self.__execute_statement(**execution_params)

            commit_params = {"transactionId": transaction_id}
            response = self.__commit_transaction(**commit_params)
        except ClientError as ce:
            logger.exception(f"Error in executing batch mutations {sql} rolling back")
            rollback_params = {"transactionId": transaction_id}
            self.__rollback_transaction(**rollback_params)

            error_code = ce.response.get("Error").get("Code")
            error_msg = ce.response.get("Error").get("Message")
            if error_code == "BadRequestException" and "Duplicate entry" in error_msg:
                raise DuplicateKeyException

            raise ce

        return RdsResponse(AuroraV1Response(response))


class AuroraV2:
    def __init__(
        self,
        db_host,
        db_port,
        db_name,
        secret_arn,
        aws_profile=None,
        aws_region=None,
        endpoint_url=None,
    ):
        self.boto_session = boto3.Session(
            profile_name=aws_profile, region_name=aws_region
        )

        if secret_arn and secret_arn.strip() != "":
            self.secret_manager = self.boto_session.client(
                "secretsmanager", endpoint_url=endpoint_url
            )
            secret_response = self.secret_manager.get_secret_value(SecretId=secret_arn)
            if "SecretString" not in secret_response:
                raise RdsException("Secret is not stored as String")

            secret_json = json.loads(secret_response["SecretString"])
            user_name = secret_json["username"]
            password = secret_json["password"]
        else:
            user_name = "root"
            password = "test"

        mysql.connector.paramstyle = "named"
        self.connection_pool = pooling.MySQLConnectionPool(
            pool_name=f"{db_name}_pool",
            pool_size=2,
            pool_reset_session=True,
            host=db_host,
            port=db_port,
            database=db_name,
            user=user_name,
            password=password,
            use_pure=True,  # required when using ssh tunnels - https://dev.mysql.com/doc/connector-python/en/connector-python-cext-development.html
        )

    @staticmethod
    def __modify_query(named_query):
        to_replace = re.findall("(:[a-zA-Z0-9_-]*)", named_query)
        modified_query = named_query
        for field in to_replace:
            field_no_colon = field[1:]
            modified_query = modified_query.replace(field, f"%({field_no_colon})s", 1)

        return modified_query

    @staticmethod
    def __execute_statement(cursor, sql, params=None):
        if params:
            # If params are passed, it is a named query
            updated_sql = AuroraV2.__modify_query(sql)
        else:
            updated_sql = sql

        formatted_sql = " ".join(updated_sql.split())
        if params:
            logger.debug(f"__execute_statement {formatted_sql} with [{params}]")
        else:
            logger.debug(f"__execute_statement {formatted_sql}")

        cursor.execute(formatted_sql, params)

    def query(self, sql, params=None, min_max_columns=None):
        conn = self.connection_pool.get_connection()
        try:
            with closing(conn.cursor()) as cursor:
                AuroraV2.__execute_statement(cursor, sql, params)
                response = RdsResponse(
                    AuroraV2Response(cursor, QueryResponseInterface.TXN_TYPE_QUERY),
                    min_max_columns,
                )

                return response
        finally:
            # closing database connection.
            if conn.is_connected():
                conn.close()

    def mutate(self, sql, params=None):
        conn = self.connection_pool.get_connection()
        try:
            with closing(conn.cursor()) as cursor:
                AuroraV2.__execute_statement(cursor, sql, params)
                response = RdsResponse(
                    AuroraV2Response(cursor, QueryResponseInterface.TXN_TYPE_MUTATE)
                )

                conn.commit()
                return response
        except mysql.connector.Error as ce:
            logger.exception("Failed to update record. Rolling back.")
            conn.rollback()
            raise ce
        except RdsException as ce:
            logger.exception("Failed to update record. Rolling back")
            conn.rollback()
            raise ce
        finally:
            # closing database connection.
            if conn.is_connected():
                conn.close()

    def batch_mutate(self, sqls, params):
        conn = self.connection_pool.get_connection()
        try:
            with closing(conn.cursor()) as cursor:
                for i in range(len(sqls)):
                    AuroraV2.__execute_statement(cursor, sqls[i], params[i])

            response = RdsResponse(
                AuroraV2Response(cursor, QueryResponseInterface.TXN_TYPE_MUTATE)
            )

            conn.commit()
            return response
        except mysql.connector.Error as ce:
            logger.exception("Failed to update record. Rolling back.")
            conn.rollback()
            raise ce
        except RdsException as ce:
            logger.exception("Failed to update record. Rolling back")
            conn.rollback()
            raise ce
        finally:
            # closing database connection.
            if conn.is_connected():
                conn.close()

    def shutdown(self):
        logger.info("Terminating all connections.")
        self.connection_pool._remove_connections()  # Accessing protected method but still required


class AuroraV2SSHTunnel:
    def __init__(
        self,
        db_host,
        db_port,
        db_name,
        secret_arn,
        jump_host,
        jump_host_private_key,
        aws_profile=None,
        aws_region=None,
        endpoint_url=None,
    ):
        db_port = db_port if db_port else 3306

        tunnel_host = "127.0.0.1"
        tunnel_port = 3306

        self.tunnel = SSHTunnelForwarder(
            (jump_host, 22),
            ssh_username="ubuntu",
            ssh_pkey=paramiko.RSAKey.from_private_key(
                io.StringIO(jump_host_private_key)
            ),
            remote_bind_address=(db_host, db_port),
            local_bind_address=(tunnel_host, tunnel_port),
        )
        self.tunnel.start()

        user_name = "rdsmainadmin"
        password = "test"
        if secret_arn and secret_arn.strip() != "":
            user_name, password = AuroraV2SSHTunnel.__get_credentials(
                aws_profile, aws_region, endpoint_url, secret_arn
            )

        mysql.connector.paramstyle = "named"
        self.connection_pool = pooling.MySQLConnectionPool(
            pool_name=f"{db_name}_pool",
            pool_size=2,
            pool_reset_session=True,
            host=self.tunnel.local_bind_host,
            port=self.tunnel.local_bind_port,
            database=db_name,
            user=user_name,
            password=password,
            use_pure=True,  # required when using ssh tunnels - https://dev.mysql.com/doc/connector-python/en/connector-python-cext-development.html
        )

    @staticmethod
    def __get_credentials(aws_profile, aws_region, endpoint_url, secret_arn):
        boto_session = boto3.Session(profile_name=aws_profile, region_name=aws_region)
        secret_manager = boto_session.client(
            "secretsmanager", endpoint_url=endpoint_url
        )
        secret_response = secret_manager.get_secret_value(SecretId=secret_arn)
        if "SecretString" not in secret_response:
            raise RdsException("Secret is not stored as String")

        secret_json = json.loads(secret_response["SecretString"])
        return secret_json["username"], secret_json["password"]

    @staticmethod
    def __modify_query(named_query):
        to_replace = re.findall("(:[a-zA-Z0-9_-]*)", named_query)
        modified_query = named_query
        for field in to_replace:
            field_no_colon = field[1:]
            modified_query = modified_query.replace(field, f"%({field_no_colon})s", 1)

        return modified_query

    @staticmethod
    def __execute_statement(cursor, sql, params=None):
        if params:
            # If params are passed, it is a named query
            updated_sql = AuroraV2SSHTunnel.__modify_query(sql)
        else:
            updated_sql = sql

        formatted_sql = " ".join(updated_sql.split())
        if params:
            logger.debug(f"__execute_statement {formatted_sql} with [{params}]")
        else:
            logger.debug(f"__execute_statement {formatted_sql}")

        cursor.execute(formatted_sql, params)

    def query(self, sql, params=None, min_max_columns=None):
        conn = self.connection_pool.get_connection()
        try:
            with closing(conn.cursor()) as cursor:
                AuroraV2SSHTunnel.__execute_statement(cursor, sql, params)
                response = RdsResponse(
                    AuroraV2Response(cursor, QueryResponseInterface.TXN_TYPE_QUERY),
                    min_max_columns,
                )

                return response
        finally:
            # closing database connection.
            if conn.is_connected():
                conn.close()

    def mutate(self, sql, params=None):
        conn = self.connection_pool.get_connection()
        try:
            with closing(conn.cursor()) as cursor:
                AuroraV2SSHTunnel.__execute_statement(cursor, sql, params)
                response = RdsResponse(
                    AuroraV2Response(cursor, QueryResponseInterface.TXN_TYPE_MUTATE)
                )

                conn.commit()
                return response
        except mysql.connector.Error as ce:
            logger.exception("Failed to update record. Rolling back.")
            conn.rollback()
            raise ce
        except RdsException as ce:
            logger.exception("Failed to update record. Rolling back")
            conn.rollback()
            raise ce
        finally:
            # closing database connection.
            if conn.is_connected():
                conn.close()

    def batch_mutate(self, sqls, params):
        conn = self.connection_pool.get_connection()
        try:
            with closing(conn.cursor()) as cursor:
                for i in range(len(sqls)):
                    AuroraV2SSHTunnel.__execute_statement(cursor, sqls[i], params[i])

            response = RdsResponse(
                AuroraV2Response(cursor, QueryResponseInterface.TXN_TYPE_MUTATE)
            )

            conn.commit()
            return response
        except mysql.connector.Error as ce:
            logger.exception("Failed to update record. Rolling back.")
            conn.rollback()
            raise ce
        except RdsException as ce:
            logger.exception("Failed to update record. Rolling back")
            conn.rollback()
            raise ce
        finally:
            # closing database connection.
            if conn.is_connected():
                conn.close()

    def shutdown(self):
        logger.info("Terminating all connections.")
        self.connection_pool._remove_connections()  # Accessing protected method but still required
        self.tunnel.close()
