import collections
import decimal
import json
import os
import re
import shutil
import unicodedata
import yaml

from typing import Any
from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


class Sanitize:
    @staticmethod
    def kebab_to_snake_case(kebab_str: str):
        return kebab_str.replace("-", "_")

    @staticmethod
    def convert_keys_to_snake_case(d):
        if isinstance(d, dict):
            new_dict = {}
            for key, value in d.items():
                new_key = Sanitize.kebab_to_snake_case(key)
                if type(value) is str or type(value) is int:
                    new_dict[new_key] = value
                else:
                    new_dict[new_key] = Sanitize.convert_keys_to_snake_case(value)
            return new_dict
        elif isinstance(d, list):
            return [Sanitize.convert_keys_to_snake_case(item) for item in d]
        else:
            return d


class Helper:
    @staticmethod
    def is_running_in_aws():
        return os.environ.get("AWS_EXECUTION_ENV") is not None

    @staticmethod
    def iso_latin_smash(s):
        """
        returns a string fitting into the "iso basic latin" (i.e. english alphabet)
        char set as best possible. First replaces unicode chars with ascii alternatives
        where available then eliminates any and all chars that aren't spaces or in
        the latin alphabet.
        """
        ascii_str = (
            unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("utf8")
        )
        return re.sub("[^A-Za-z ]", "", ascii_str)

    @staticmethod
    def round_number(number, direction=None, exponent=".01"):
        """
        returns quantised decimal based on input number and exponent.
        direction defaults to None - (default rounding on quantize), can be 'up' or 'down' too
        """
        rounding = {
            "up": decimal.ROUND_UP,
            "down": decimal.ROUND_DOWN,
            "fair": decimal.ROUND_HALF_EVEN,
        }
        return decimal.Decimal(number).quantize(
            decimal.Decimal(exponent), rounding=rounding.get(direction)
        )

    @staticmethod
    def field_mapper(record, mappings):
        entries = {}
        for key, mapping in mappings.items():
            extra_key, mapper = mapping

            value = record.get(key)
            if value:
                if mapper:
                    entries[extra_key] = mapper(value)
                else:
                    entries[extra_key] = value

        record.update(entries)
        return record

    @staticmethod
    def prepare_helm_chart(source_folder, output_folder, values_dict):
        if os.path.exists(output_folder):
            shutil.rmtree(output_folder)
        shutil.copytree(source_folder, output_folder)

        values_file_path = os.path.join(output_folder, "values.yaml")
        with open(values_file_path, "w") as outfile:
            yaml.dump(values_dict, outfile, default_flow_style=False)

        return values_file_path


class DictUtils:
    @staticmethod
    def strip_null(record, *keys):
        """
        returns a copy of record, omitting any of the fields whose value is 'null'
        """
        return {k: v for k, v in record.items() if v is not None}

    @staticmethod
    def dict_without(d, *keys):
        """
        returns a copy of d, excluding any of the *keys given
        """
        skeys = set(keys)
        return {k: v for k, v in d.items() if k not in skeys}

    @staticmethod
    def dict_if(key, value):
        """
        Simplify a recurrent pattern; a maybe-included field in a dict, viz
            body = { ..., **({key:value} if value else {}), ... }
        by either expanding to a dict with the given field, or an empty dict,
        thus eliding said field.  this returns a dict with the field if it is
        not 'falsy', otherwise an empty dict, thus making the above
            body = { ..., **dict_if(key, value), ... }
        """
        return {key: value} if value else {}

    @staticmethod
    def prefix_dict(prefix, d):
        """
        returns a new dict with each key having prefix added. if d is not a mapping,
        or keys aren't str, raises a ValueError
        """
        if not isinstance(d, collections.abc.Mapping) or not all(
            isinstance(k, str) for k in d
        ):
            raise TypeError("dict must have str keys")
        return {f"{prefix}{k}": v for k, v in d.items()}

    @staticmethod
    def prefix_strip_dict(prefix, d, /, require=False):
        """
        returns a new dict with `prefix` stripped from the keys.
        keys lacking the prefix are passed unchanged, unless `require` is given,
        when their presence will raise a ValueError
        """
        if require and not all(k.startswith(prefix) for k in d):
            raise ValueError("keys do not all start with required prefix")
        return {k[len(prefix) :]: v for k, v in d.items()}

    @staticmethod
    def compare_dict(reference: Any, comparison: Any) -> bool:
        if reference is None:
            return False

        # Handle lists
        if isinstance(reference, list) and isinstance(comparison, list):
            reference_sorted = sorted(
                reference,
                key=lambda x: json.dumps(x, sort_keys=True)
                if isinstance(x, dict)
                else x,
            )
            comparison_sorted = sorted(
                comparison,
                key=lambda x: json.dumps(x, sort_keys=True)
                if isinstance(x, dict)
                else x,
            )
            return reference_sorted != comparison_sorted

        # Handle dict
        if isinstance(reference, dict) and isinstance(comparison, dict):
            return any(
                key not in comparison or DictUtils.compare_dict(value, comparison.get(key))
                for key, value in reference.items()
            )

        return reference != comparison


class LazyProp:
    def __init__(self, method, /):
        # logger.debug(f'LazyProp.init({method})')
        self.method = method

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self

        if self not in obj.__dict__:
            # logger.debug(f'LazyProp: invoking {self.method}')
            obj.__dict__[self] = self.method(obj)
            # logger.debug(f'LazyProp: {self.method} ↦ {obj.__dict__[self]}')
        return obj.__dict__[self]

    def __set__(self, obj, value):
        raise AttributeError("can't set attribute")

    def __delete__(self, obj):
        raise AttributeError("can't delete attribute")


class JsonHelper:
    @staticmethod
    def __at_path(obj, inner_path):
        if inner_path:
            return JsonHelper.__at_path(obj.get(inner_path[0], {}), inner_path[1:])
        else:
            return obj

    @staticmethod
    def filter_exclude_marked(list_objs, path, value):
        """
        returns a filtered list of objects, removing any who have a value matching `value`
        within their structure in the field referenced by path.
        """
        return [obj for obj in list_objs if JsonHelper.__at_path(obj, path) != value]

    @staticmethod
    def filter_include_marked(list_objs, path, value):
        """
        returns a filtered list of objects, keeping any who have a value matching `value`
        within their structure in the field referenced by path.
        """
        return [obj for obj in list_objs if JsonHelper.__at_path(obj, path) == value]
