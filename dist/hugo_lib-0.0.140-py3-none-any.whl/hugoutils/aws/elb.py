import boto3
from botocore.exceptions import WaiterError
from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


class ELB:
    def __init__(self, boto_profile=None, region=None, endpoint_url=None):
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)
        self.client = self.boto_session.client("elbv2", endpoint_url=endpoint_url)

    def register_load_balancer(
        self, target_group_arn: str, loadbalancer_arn: str, target_ports: list
    ):
        logger.info(
            f"Registering load balancers to target groups on ports {target_ports}"
        )

        # Wait for the load balancer to become active
        waiter = self.client.get_waiter("load_balancer_available")
        try:
            waiter.wait(
                LoadBalancerArns=[loadbalancer_arn],
                WaiterConfig={
                    "Delay": 15,  # Check every 15 seconds
                    "MaxAttempts": 40,  # Total wait time: 10 minutes
                },
            )
        except WaiterError as e:
            logger.error(f"Timeout waiting for load balancer to become active: {e}")
            raise

        self.client.register_targets(
            TargetGroupArn=target_group_arn,
            Targets=[{"Id": loadbalancer_arn, "Port": port} for port in target_ports],
        )
