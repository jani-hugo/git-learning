class RdsModel:
    """Base RDS model for methods used by all Models"""

    @staticmethod
    def make_list_params(suffix, values):
        fields = []
        parameter_dict = {}

        i = 0
        for value in values:
            i = i + 1
            field_name = f"{suffix}_{i}"
            fields.append(f":{field_name}")
            parameter_dict[field_name] = value

        fields = ",".join(fields)
        return fields, parameter_dict
