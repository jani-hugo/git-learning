import ast
import dataclasses
import distutils.util
from dataclasses import is_dataclass
from typing import List, Type, Dict, Any, TypeVar

import behave.model
from dacite import Config, from_dict
from dacite.types import extract_optional, is_optional

T = TypeVar("T")


class DataClassParser(object):
    """Utility class for parsing feature file table rows into dataclass instances."""

    @staticmethod
    def parse_rows(rows: List[behave.model.Row], data_class: Type[T]) -> List:
        """Parses multiple Behave table rows into a list of dataclass instances."""
        result = []
        for row in rows:
            result.append(DataClassParser.parse_row(row, data_class))
        return result

    @staticmethod
    def parse_row(row: behave.model.Row, data_class: Type[T]) -> List:
        """Parses a single Behave table row into a dataclass instance."""
        attribute_data = {}
        for heading, cell_text in row.items():  # SEE CLASS: behave.model.Row
            attribute_type = DataClassParser.__select_attribute_parser(heading, data_class)
            if attribute_type is None:
                continue

            # Convert to attribute value
            cell_value = DataClassParser.__parse_attribute(cell_text, attribute_type)
            attribute_data[heading] = cell_value

        return DataClassParser.dict_to_object(attribute_data, data_class)

    @staticmethod
    def dict_to_object(data: Dict[str, Any], data_class: Type[T]) -> Any:
        """Converts a dictionary into a dataclass instance using dacite."""
        return from_dict(data_class=data_class, data=data, config=Config(check_types=False))

    @staticmethod
    def row_to_dict(table_rows: List[behave.model.Row]) -> List[Dict[str, str]]:
        """Parses Behave table rows into a list of dictionaries."""
        rows = []
        for table_row in table_rows:
            attribute_data = {}
            for heading, cell_text in table_row.items():
                attribute_data[heading] = cell_text
            rows.append(attribute_data)
        return rows

    @staticmethod
    def __select_attribute_parser(attribute_name, data_class):
        """Selects the appropriate attribute type from the dataclass fields."""
        # If attribute not present in class
        for field in dataclasses.fields(data_class):
            if field.name == attribute_name:
                return extract_optional(field.type) if is_optional(field.type) else field.type

        return None

    @staticmethod
    def __parse_attribute(cell_text, attribute_type):
        """Parses a string value from a Behave table into the correct attribute type."""
        if is_dataclass(attribute_type):
            if cell_text == '':
                return None
            inner_dict = ast.literal_eval(str(cell_text))
            return from_dict(
                data_class=attribute_type, data=inner_dict, config=Config(check_types=False)
            )
        elif attribute_type is bool:
            return bool(distutils.util.strtobool(cell_text))
        elif attribute_type in {dict, list}:
            return ast.literal_eval(str(cell_text))
        return attribute_type(cell_text)
