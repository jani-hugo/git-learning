from enum import Enum, unique

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger("RDSResponse")


@unique
class ResponseCodes(Enum):
    SUCCESS = 200
    FAILURE_RDS = 400
    FAILURE_WITH_ROLLBACK = 500
    FAILURE_WITH_FAILED_ROLLBACK = 550
    FAILURE_NO_RESPONSE = 650


class RdsException(Exception):
    def __init__(self, status):
        self.status = status


class DuplicateKeyException(Exception):
    pass


class QueryResponseInterface:
    TXN_TYPE_MUTATE = "mutate"
    TXN_TYPE_QUERY = "query"

    def transaction_type(self):
        # Method to return the transaction type
        pass

    def transaction_status(self):
        # Method to return the transaction status
        pass

    def columns(self):
        # Method to return the column names
        pass

    def rows(self):
        # Method to return the rows
        pass


class AuroraV1Response(QueryResponseInterface):
    def __init__(self, v1_response):
        self.__type = None
        self.__status = ResponseCodes.FAILURE_WITH_ROLLBACK
        self.__columns = []
        self.__rows = []

        if not v1_response:
            return

        if "transactionStatus" in v1_response:
            self.__type = QueryResponseInterface.TXN_TYPE_MUTATE

            if v1_response.get("transactionStatus") == "Transaction Committed":
                self.__status = ResponseCodes.SUCCESS
            elif v1_response.get("transactionStatus") == "Rollback Complete":
                self.__status = ResponseCodes.FAILURE_WITH_ROLLBACK
            else:
                self.__status = ResponseCodes.FAILURE_WITH_FAILED_ROLLBACK
        else:
            self.__type = QueryResponseInterface.TXN_TYPE_QUERY

            if v1_response.get("ResponseMetadata").get("HTTPStatusCode") == 200:
                self.__status = ResponseCodes.SUCCESS

                self.__columns = []
                for attributes in v1_response.get("columnMetadata"):
                    self.__columns.append(attributes["label"])

                self.__rows = []
                for _, record in enumerate(v1_response["records"]):
                    row_tuple = ()
                    for i, j in enumerate(record):
                        data_type = list(j.keys())[0]
                        field_value = list(j.values())[0]
                        if data_type != "isNull":
                            row_tuple = row_tuple + (field_value,)
                        else:
                            row_tuple = row_tuple + (None,)
                    self.__rows.append(row_tuple)
            else:
                self.__status = ResponseCodes.FAILURE_RDS

    def transaction_type(self):
        return self.__type

    def transaction_status(self):
        return self.__status

    def columns(self):
        return self.__columns

    def rows(self):
        return self.__rows


class AuroraV2Response(QueryResponseInterface):
    def __init__(self, mysql_cursor, txn_type):
        if not mysql_cursor:
            self.__type = None
            self.__status = ResponseCodes.FAILURE_RDS
            self.__columns = []
            self.__rows = []
            return

        self.__type = txn_type
        self.__status = ResponseCodes.SUCCESS
        self.__columns = []
        self.__rows = []

        if self.__type == QueryResponseInterface.TXN_TYPE_QUERY:
            self.__columns = mysql_cursor.column_names
            self.__rows = mysql_cursor.fetchall()

    def transaction_type(self):
        return self.__type

    def transaction_status(self):
        return self.__status

    def columns(self):
        return self.__columns

    def rows(self):
        return self.__rows


class RdsResponse:
    MAX = "max"
    MIN = "min"

    def __init__(self, query_response, min_max_columns=None):
        """Set the response
        self.__type: (str) 'mutate' or 'query' set by looking at transactionStatus
        field in rds-data response
        self.__status (Enum) - the status code of the transaction
        self.__data (list) - a list of dictionaries, the keys of which correspond to sql
            columns in the select query
        in the sql select query. Note data remains an empty list for mutations.
        """

        if query_response.transaction_status() != ResponseCodes.SUCCESS:
            logger.info(f"Failed to fetch the response from RDS {self}")
            raise RdsException(query_response.transaction_status())

        self.__query_response = query_response
        self.__data = []
        self.__mm_records = {}

        if (
            self.__query_response.transaction_type()
            == QueryResponseInterface.TXN_TYPE_QUERY
        ):
            self.__data, self.__mm_records = self.__parse_response(
                query_response, min_max_columns
            )

    def get_all(self):
        return self.__data

    def get_one(self):
        try:
            return self.__data[0]
        except:
            return None

    def get_mm_records(self):
        return self.__mm_records

    def get_min_value(self, column):
        return self.__mm_records.get(column, {}).get(RdsResponse.MIN, -1)

    def get_max_value(self, column):
        return self.__mm_records.get(column, {}).get(RdsResponse.MAX, -1)

    @staticmethod
    def __parse_response(query_response, min_max_columns):
        """Return SQL records in response['records']
        Return a dictionary containing columns that were in the
        SQL query"""
        record_list = []
        mm_records = {}
        if min_max_columns:
            for column in min_max_columns:
                mm_records[column] = {RdsResponse.MIN: -1, RdsResponse.MAX: -1}

        try:
            columns = query_response.columns()
            for _, row_tuple in enumerate(query_response.rows()):
                output_record = {}
                for i, field_value in enumerate(row_tuple):
                    column = columns[i]
                    output_record[column] = field_value

                    if column in mm_records:
                        mm_record = mm_records.get(column)
                        try:
                            min_value = mm_record.get(RdsResponse.MIN)
                            max_value = mm_record.get(RdsResponse.MAX)
                            if min_value == -1 or min_value > int(field_value):
                                mm_record[RdsResponse.MIN] = int(field_value)
                            if max_value == -1 or max_value < int(field_value):
                                mm_record[RdsResponse.MAX] = int(field_value)
                        except:
                            logger.exception(
                                f"Failed to parse field [{field_value}]. "
                                f"column: {column}, mm_record: {mm_record}"
                            )

                record_list.append(output_record)
        except Exception as e:
            logger.exception(f"Could not retrieve SQL record")
            raise e

        return record_list, mm_records
