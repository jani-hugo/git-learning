from pathlib import Path
import os
import subprocess
import time

import yaml

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger("StackUtil")


class CommonUtils:
    @staticmethod
    def read_file(file_path):
        with open(file_path, "r") as file:
            return file.read()

    @staticmethod
    def write_file(file_path, content):
        Path(file_path).parent.mkdir(exist_ok=True, parents=True)
        with open(file_path, "w") as file:
            file.write(content)
            file.close()

    @staticmethod
    def read_yaml(yaml_file):
        with open(yaml_file, "r") as file:
            yaml_file = yaml.safe_load(file)
            return dict(yaml_file.items())

    @staticmethod
    def wait_until(some_predicate, timeout, period=0.25, *args, **kwargs):
        must_end = time.time() + timeout
        while time.time() < must_end:
            if some_predicate(*args, **kwargs):
                return True
            time.sleep(period)

        return False

    @staticmethod
    def run_command(command, path=None):
        if path is None:
            path = os.getcwd()

        res = subprocess.run(command, shell=True, capture_output=True, cwd=path)

        try:
            res.check_returncode()
        except subprocess.CalledProcessError as ce:
            logger.error(
                f"************** Error code {res.returncode} received from process for following command **************"
            )
            logger.error(command)
            logger.error(f"Error Output: {res.stderr.decode().strip()}")
            raise ce

        return res.stdout.decode()

    @staticmethod
    def delete_file(file_path):
        if os.path.exists(file_path):
            os.remove(file_path)
        else:
            print("The file does not exist")

    @staticmethod
    def log(message):
        logger.info(message)

