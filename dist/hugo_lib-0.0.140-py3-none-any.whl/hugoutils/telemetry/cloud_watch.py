from enum import Enum

from botocore.exceptions import ClientError
import boto3

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


class CloudWatchUnit(Enum):
    SECONDS = "Seconds"
    MICROSECONDS = "Microseconds"
    MILLISECONDS = "Milliseconds"
    BYTES = "Bytes"
    KILOBYTES = "Kilobytes"
    MEGABYTES = "Megabytes"
    GIGABYTES = "Gigabytes"
    TERABYTES = "Terabytes"
    COUNT = "Count"
    PERCENT = "Percent"
    COUNT_PER_SEC = "Count/Second"
    NONE = "None"


class CloudWatchNameSpace(Enum):
    NAMESPACE_ENTITY_QUARANTINE = "Hugo/EntityQuarantine"
    NAMESPACE_LITE_TXN_QUEUE = "Hugo/LiteTxnQueue"


# Copied from
# https://docs.aws.amazon.com/code-samples/latest/catalog/python-cloudwatch-cloudwatch_basics.py.html
class CloudWatch:
    """Encapsulates Amazon CloudWatch functions."""

    def __init__(self, boto_profile=None, region=None, endpoint_url=None):
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)
        self.cloudwatch_resource = self.boto_session.resource(
            "cloudwatch", endpoint_url=endpoint_url
        )

    def put_metric_data(
        self, namespace: CloudWatchNameSpace, name, unit: CloudWatchUnit, value
    ):
        try:
            logger.info("Put data for metric %s.%s", namespace.value, name)

            metric = self.cloudwatch_resource.Metric(namespace.value, name)
            metric.put_data(
                Namespace=namespace.value,
                MetricData=[{"MetricName": name, "Value": value, "Unit": unit.value}],
            )
        except ClientError:
            logger.exception(
                "Couldn't put data for metric %s.%s", namespace.value, name
            )

    def put_metric_data_set(
        self, namespace: CloudWatchNameSpace, name, unit: CloudWatchUnit, data_set
    ):
        try:
            logger.info("Put data set for metric %s.%s.", namespace.value, name)

            metric = self.cloudwatch_resource.Metric(namespace.value, name)
            metric.put_data(
                Namespace=namespace.value,
                MetricData=[
                    {
                        "MetricName": name,
                        "Values": data_set["values"],
                        "Counts": data_set["counts"],
                        "Unit": unit.value,
                    }
                ],
            )
        except ClientError:
            logger.exception(
                "Couldn't put data set for metric %s.%s.", namespace.value, name
            )
