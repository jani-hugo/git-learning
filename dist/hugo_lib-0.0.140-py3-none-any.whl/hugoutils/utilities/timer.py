import inspect
import time

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


class Timer:
    def __init__(self, label=None, auto_report_threshold=0.01, show_stack=None):
        self.label = label
        self.threshold = auto_report_threshold
        self.show_stack = show_stack

    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, t, v, tb):
        elapsed = self.elapsed()
        if self.threshold is not None and elapsed > self.threshold:
            if not self.label or self.show_stack:
                logger.debug(f"timeit: timer {self.label!r} took {elapsed:.3f}s at:")
                try:
                    fi = inspect.stack()[1]
                    logger.debug(
                        f'  File "{fi.filename}", line {fi.lineno}, in {fi.function}'
                    )
                    logger.debug(f"    {fi.code_context[fi.index].strip()}")
                except Exception:
                    logger.exception("didn't expect that!")
            else:
                logger.debug(f"timeit: timer {self.label!r} took {elapsed:.3f}s")

    def elapsed(self):
        return time.time() - self.start
