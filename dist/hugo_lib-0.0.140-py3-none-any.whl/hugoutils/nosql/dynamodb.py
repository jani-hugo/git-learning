import boto3
import botocore


class DynamoDbApi:
    def __init__(self, table_name, boto_profile=None, region=None, endpoint_url=None):
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)

        self.ddb = self.boto_session.client("dynamodb", endpoint_url=endpoint_url)
        self.ddb_resource = boto3.resource("dynamodb", region_name=region)
        self.ddb_table = self.ddb_resource.Table(table_name)
        self.table_name = table_name
        self.endpoint_url = endpoint_url

    def get_schema(self):
        response = self.ddb.describe_table(TableName=self.table_name)
        table_struct = response["Table"]
        hash_key = ""
        range_key = ""
        for schema in table_struct["KeySchema"]:
            attr_name = schema["AttributeName"]
            key_type = schema["KeyType"]
            if key_type == "HASH":
                hash_key = attr_name
            elif key_type == "RANGE":
                range_key = attr_name
        return hash_key, range_key

    def get_all_items(self, page_token=None, segment=None, total_segments=None):
        scan_result = None
        if page_token is not None:
            scan_result = self.ddb.scan(
                TableName=self.table_name, ExclusiveStartKey=page_token
            )
        else:
            scan_result = self.ddb.scan(TableName=self.table_name)
        return scan_result.get("Items", []), scan_result.get("LastEvaluatedKey", None)

    def get_all_items_parallel(self, segment, total_segments, page_token=None):
        scan_result = None
        if page_token is not None:
            scan_result = self.ddb.scan(
                TableName=self.table_name,
                ExclusiveStartKey=page_token,
                Segment=segment,
                TotalSegments=total_segments,
            )
        else:
            scan_result = self.ddb.scan(
                TableName=self.table_name,
                Segment=segment,
                TotalSegments=total_segments,
            )
        return scan_result.get("Items", []), scan_result.get("LastEvaluatedKey", None)

    def put_item(self, item: dict, hash_key: str, range_key: str = None):
        if range_key is not None and range_key != "":
            condition_expr = f"attribute_not_exists({hash_key}) and attribute_not_exists({range_key})"
        else:
            condition_expr = f"attribute_not_exists({hash_key})"

        try:
            self.ddb.put_item(
                TableName=self.table_name, Item=item, ConditionExpression=condition_expr
            )
        except self.ddb.exceptions.TableNotFoundException as e:
            raise e
        except botocore.exceptions.ClientError as e:
            if e.response["Error"]["Code"] != "ConditionalCheckFailedException":
                raise
        except Exception as e:
            raise e
