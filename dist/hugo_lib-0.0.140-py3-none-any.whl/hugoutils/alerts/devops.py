from enum import Enum, unique
import json

import requests

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


@unique
class Channel(Enum):
    SUPPORT = "support"
    ENG = "eng"
    TEST = "test"


@unique
class Priority(Enum):
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"
    P4 = "P4"
    P5 = "P5"


class SquadCast:
    def __init__(self):
        api_end_point = "https://api.squadcast.com/v2/incidents/api"
        self.end_points = {
            "support": f"{api_end_point}/ab93f8f576ae06471cac35970dc16c84abc2028",
            "eng": f"{api_end_point}/fdfb63ecbe98bfbbd2a1ba98c1411e699f4a8b39",
        }

    def alert(self, title, description, priority, channel, **kwargs):
        try:
            url = self.end_points.get(channel.value, None)
            if url is None:
                logger.warning(f"No url defined for channel {channel.value}")
                return

            tags = {**kwargs, "Priority": priority.value}
            payload = {"message": title, "description": description, "tags": tags}

            headers = {"content-type": "application/json"}
            req = requests.post(
                url, data=bytes(json.dumps(payload).encode("utf-8")), headers=headers
            )

            if req.status_code != 200:
                logger.warning(
                    f"Request failed with status code {req.status_code} : {req.content}"
                )
                return
        except:
            logger.exception("Unable to create an incident with Squadcast")


def alert(title, description, priority: Priority, channel: Channel, **kwargs):
    logger.warning(
        f"title {title}, description: {description}, priority: {priority}, channel: {channel}"
    )
    SquadCast().alert(title, description, priority, channel, **kwargs)
