import logging


class LogManager:
    @staticmethod
    def get_logger(name=None):
        if len(logging.getLogger().handlers) > 0:
            # then we're very likely in aws lambda with a pre-existing root handler
            logging.getLogger().setLevel(logging.INFO)
        else:
            logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)

        return logger
