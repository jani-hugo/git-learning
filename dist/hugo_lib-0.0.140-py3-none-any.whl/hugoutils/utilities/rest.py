from enum import Enum, unique
import asyncio

import aiohttp

from hugoutils.telemetry.logger import LogManager
from hugoutils.utilities.timer import Timer
from hugoutils.utilities.utilities import DictUtils

logger = LogManager.get_logger(__name__)


class Requests:
    @staticmethod
    def parallel_batch_request(requests, timer_report_threshold=1.0):
        spammy = False

        async def async_fetch(client, req):
            if spammy:
                logger.debug(f"async_fetch({req})")

            async with client.request(
                req.method,
                req.url,
                params=req.params,
                headers=req.headers,
                json=req.body,
                raise_for_status=req.raise_for_status,
            ) as async_response:
                if spammy:
                    logger.debug(f"async_response: {async_response!r}")
                with Timer(f"await {req}", timer_report_threshold):
                    ret = await async_response.json()
                return req.convert_data(ret)

        async def async_fetch_all():
            timeout = aiohttp.ClientTimeout(total=900)
            async with aiohttp.ClientSession(timeout=timeout) as client:
                fetches = [async_fetch(client, request) for request in requests]
                with Timer(
                    f"await gather(*fetches[{len(fetches)}])", timer_report_threshold
                ):
                    ret = await asyncio.gather(*fetches)
                return ret

        def run_async_fetch():
            with Timer("parallel_batch_request", timer_report_threshold) as timer:
                loop = asyncio.get_event_loop()
                results = loop.run_until_complete(async_fetch_all())
                logger.debug(f"parallel_batch_request took {timer.elapsed():.3f}s")
            return results

        return run_async_fetch()


@unique
class RestResponseCodes(Enum):
    OK = 200
    CLIENT_ERROR_MISSING_PARAMETERS = 400
    SERVER_ERROR = 500


class RestResponse:
    """A utility for generating a consistent rest response
    that always contains:
        status - OK
               - CLIENT_ERROR_MISSING_PARAMETERS
               - SERVER_ERROR
        data - populated with a list of dictionaries for queries, empty if mutation
        message - error message, if fail occurs
    """

    def __init__(
        self, rest_response_code: RestResponseCodes, data=None, page_token=None
    ):
        self.__status = rest_response_code.value
        self.__message = rest_response_code.name
        self.__data = data
        self.__page_token = page_token

    def get_response(self):
        return DictUtils.strip_null(
            {
                "status": self.__status,
                "message": self.__message,
                "data": self.__data,
                "page_token": self.__page_token,
            }
        )

    def is_success(self):
        return self.__status == RestResponseCodes.OK.value

    @staticmethod
    def get_missing_params_error_response():
        return RestResponse(
            RestResponseCodes.CLIENT_ERROR_MISSING_PARAMETERS
        ).get_response()

    @staticmethod
    def get_server_error_response():
        return RestResponse(RestResponseCodes.SERVER_ERROR).get_response()

    @staticmethod
    def get_success_response(data=None, page_token=None):
        return RestResponse(RestResponseCodes.OK, data, page_token).get_response()
