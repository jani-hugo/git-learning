import boto3


class ParamStoreApi:
    def __init__(self, stack_name, boto_profile=None, region=None, endpoint_url=None):
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)

        self.ssm = self.boto_session.client("ssm", endpoint_url=endpoint_url)
        self.path_prefix = f"/{stack_name}"

    def update_store(self, name, value, secure=True):
        if not name.startswith("/"):
            raise ValueError("Invalid Name. Names should always starts with '/'")

        value_type = "SecureString" if secure else "String"
        full_path = f"{self.path_prefix}{name}"
        self.ssm.put_parameter(
            Name=full_path,
            Value=value,
            Type=value_type,
            DataType="text",
            Overwrite=True,
            Tier="Intelligent-Tiering",
        )

    def get_all_parameters(self):
        store = {}

        paginator = self.ssm.get_paginator("describe_parameters")
        page_iterator = paginator.paginate().build_full_result()
        for page in page_iterator["Parameters"]:
            name = page["Name"]
            if not name.startswith(self.path_prefix):
                continue

            value = self.fetch_parameter_value(name)
            update_name = name[len(self.path_prefix) :]
            store[update_name] = value

        return store

    def get_parameter_value(self, name, default_value=""):
        try:
            if not name.startswith("/"):
                raise ValueError("Invalid Name. Names should always starts with '/'")

            full_path = f"{self.path_prefix}{name}"
            return self.fetch_parameter_value(full_path)
        except:
            return default_value

    def fetch_parameter_value(self, full_path):
        response = self.ssm.get_parameter(Name=full_path, WithDecryption=True)
        return response["Parameter"]["Value"]
