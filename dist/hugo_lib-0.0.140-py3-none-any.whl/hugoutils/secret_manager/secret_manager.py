from botocore.exceptions import ClientError
import boto3

from hugoutils.utilities.common_utils import CommonUtils


class SecretManagerApi:
    def __init__(self, stack_name, boto_profile=None, region=None, endpoint_url=None):
        self.stack_name = stack_name
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)
        self.secret_manager = self.boto_session.client(
            "secretsmanager", endpoint_url=endpoint_url
        )

    def get_secret_name(self, name):
        return f"{self.stack_name}-{name}"

    def create_secret(self, name, secret_value):
        secret_name = self.get_secret_name(name)
        try:
            self.secret_manager.get_secret_value(SecretId=secret_name)
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                CommonUtils.log(
                    f"The requested secret {secret_name} was not found, creating one."
                )
                try:
                    if isinstance(secret_value, str):
                        response = self.secret_manager.create_secret(
                            Name=secret_name, SecretString=secret_value
                        )
                    elif isinstance(secret_value, bytes):
                        response = self.secret_manager.create_secret(
                            Name=secret_name, SecretBinary=secret_value
                        )
                    else:
                        raise ValueError("Invalid type for 'secret_value'")
                except ClientError as ce:
                    CommonUtils.log(
                        f"Error putting secret value in secrets_manager - {ce}"
                    )
                    raise ValueError("Error putting secret in secretmanager")
                else:
                    CommonUtils.log("Successfully put secret in secret_manager")
                    secret_arn = response.get("ARN")
            else:
                CommonUtils.log(f"Error putting secret value in secrets_manager - {e}")
                raise ValueError("Error putting secret in secretmanager")
        else:
            CommonUtils.log(
                f"Secret with name {secret_name} already exists in the secret_manager, updating it with new value"
            )
            try:
                if isinstance(secret_value, str):
                    response = self.secret_manager.update_secret(
                        SecretId=secret_name, SecretString=secret_value
                    )
                elif isinstance(secret_value, bytes):
                    response = self.secret_manager.update_secret(
                        SecretId=secret_name, SecretBinary=secret_value
                    )
                else:
                    raise ValueError("Invalid type for 'secret_value'")
            except ClientError as ce:
                CommonUtils.log(f"Error putting secret value in secrets_manager - {ce}")
                raise ValueError("Error putting secret in secretmanager")
            else:
                CommonUtils.log(f"Successfully put secret in secret_manager")
                secret_arn = response.get("ARN")

        return secret_arn

    def get_secret(self, name):
        secret_name = self.get_secret_name(name)
        try:
            response = self.secret_manager.get_secret_value(SecretId=secret_name)
        except ClientError as e:
            raise ValueError(f"No secret exists for {name} under {self.stack_name}")
