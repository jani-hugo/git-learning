from collections.abc import Mapping
from datetime import datetime
from decimal import Decimal
import json

from amazon.ion.simple_types import is_null
from amazon.ion.simpleion import dumps, loads
from pyqldb.config.retry_config import RetryConfig
from pyqldb.driver.qldb_driver import QldbDriver
import boto3

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


class QldbApi:
    def __init__(self, ledger_name, boto_profile=None, region=None, endpoint_url=None):
        self.boto_session = boto3.Session(profile_name=boto_profile, region_name=region)

        self.qldb_driver = QldbDriver(
            ledger_name=ledger_name,
            retry_config=RetryConfig(retry_limit=4),
            boto3_session=self.boto_session,
            endpoint_url=endpoint_url,
        )

    def run_qldb_query(self, query_str, *args):
        """
        Execute an SQL Query statement for QLDB Ledger
        """

        def thunk(executor):
            cursor = executor.execute_statement(query_str, *args)
            return list(cursor)

        try:
            return self.qldb_driver.execute_lambda(thunk)
        except Exception as ex:
            logger.exception(f"Exception while executing QLDB", str(ex))
            raise

    @staticmethod
    def deionize(obj):
        if isinstance(obj, Mapping):
            return {k: QldbApi.deionize(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [QldbApi.deionize(v) for v in obj]
        elif is_null(obj):
            return None
        elif isinstance(obj, Decimal):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        else:
            # move along, nothing interesting to see here...
            return obj

    @staticmethod
    def ionize(obj):
        """
        Convert a Python object into an Ion object.

        :type py_object: object
        :param py_object: The object to convert.

        :rtype: :py:class:`amazon.ion.simple_types.IonPyValue`
        :return: The converted Ion object.
        """
        return loads(dumps(obj))

    @staticmethod
    def nullable_dict(d):
        return {k: v if not is_null(v) else None for k, v in d.items()}

    @staticmethod
    def maybe_date_fields(row, *fields):
        return {field: row[field].isoformat() for field in fields if field in row}

    @staticmethod
    def maybe_ion_fields(row, *fields):
        return {field: QldbApi.deionize(row[field]) for field in fields if field in row}

    @staticmethod
    def maybe_json_fields(row, *fields):
        return {field: json.loads(row[field]) for field in fields if field in row}

    @staticmethod
    def unmarshal(row, date_fields=None, ion_fields=None, json_fields=None):
        return {
            **QldbApi.nullable_dict(row),
            **QldbApi.maybe_date_fields(row, *date_fields),
            **QldbApi.maybe_ion_fields(row, *ion_fields),
            **QldbApi.maybe_json_fields(row, *json_fields),
        }
