import json
import logging
import time
from typing import Optional, Dict, Any
from urllib.parse import urlparse

import requests

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

default_headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
}

MAX_RETRY_SERVER_ERROR = 1


class RestUtil:
    @staticmethod
    def post(url: str, body: dict = None, headers: dict = None,
             raise_for_status: bool = True, assert_status_codes: tuple = "200"):
        if headers is not None:
            headers = {**default_headers, **headers}
        else:
            headers = default_headers

        response = None
        for _ in range(MAX_RETRY_SERVER_ERROR):
            response = requests.post(
                url=url,
                data=json.dumps(body),
                headers=headers,
                verify=RestUtil.__verify_scheme(url)
            )
            if response.status_code < 500:
                break
            time.sleep(5)

        if raise_for_status:
            response.raise_for_status()

        json_response = json.loads(response.text)
        RestUtil.__raise_for_hugo_status_code(json_response, assert_status_codes)
        return json_response

    @staticmethod
    def get(url: str, params: dict = None, headers: dict = None,
            raise_for_status: bool = True, assert_status_codes: tuple = "200"):
        if headers is not None:
            headers = {**default_headers, **headers}
        else:
            headers = default_headers

        response = None
        for _ in range(MAX_RETRY_SERVER_ERROR):
            response = requests.get(url, params=params, headers=headers,
                                    verify=RestUtil.__verify_scheme(url))
            if response.status_code < 500:
                break
            time.sleep(5)

        if raise_for_status:
            response.raise_for_status()

        json_response = json.loads(response.text)
        RestUtil.__raise_for_hugo_status_code(json_response, assert_status_codes)
        return json_response

    @staticmethod
    def delete(url: str, body: dict = None, params: dict = None, headers: dict = None,
               raise_for_status: bool = True, assert_status_codes: tuple = "200"):
        if headers is not None:
            headers = {**default_headers, **headers}
        else:
            headers = default_headers

        response = None
        for _ in range(MAX_RETRY_SERVER_ERROR):
            response = requests.delete(url, data=json.dumps(body), params=params, headers=headers,
                                       verify=RestUtil.__verify_scheme(url))
            if response.status_code < 500:
                break
            time.sleep(5)

        if raise_for_status:
            response.raise_for_status()
        json_response = json.loads(response.text)
        RestUtil.__raise_for_hugo_status_code(json_response, assert_status_codes)
        return json_response

    @staticmethod
    def put(url: str, body: dict = None, headers: dict = None,
            raise_for_status: bool = True, assert_status_codes: tuple = "200"):
        if headers is not None:
            headers = {**default_headers, **headers}
        else:
            headers = default_headers

        response = None
        for _ in range(MAX_RETRY_SERVER_ERROR):
            response = requests.put(url, data=json.dumps(body), headers=headers,
                                    verify=RestUtil.__verify_scheme(url))
            if response.status_code < 500:
                break
            time.sleep(5)

        if raise_for_status:
            response.raise_for_status()
        json_response = json.loads(response.text)
        RestUtil.__raise_for_hugo_status_code(json_response, assert_status_codes)
        return json_response

    @staticmethod
    def __verify_scheme(url: str) -> bool:
        parsed_url = urlparse(url)
        return parsed_url.scheme == "https"

    @staticmethod
    def __raise_for_hugo_status_code(response_body: dict, assert_status_codes: tuple):
        assert response_body is not None, logger.error(
            "Expected response body not None\n"
            f"Actual response body: {json.dumps(response_body)}"
        )

        assert "headers" in response_body, logger.error(
            "Expected headers in response body\n"
            f"Actual response body: {json.dumps(response_body)}"
        )

        status_code = response_body["headers"].get("status_code") or response_body["headers"].get("statusCode")
        trace_id = response_body["headers"].get("trace_id") or response_body["headers"].get("traceId")

        assert status_code in assert_status_codes, logger.error(
            f"[TraceId: {trace_id}]\n"
            f"Expect status code: {assert_status_codes}\n"
            f"Actual status code: {status_code}\n"
            f"Actual response body: {json.dumps(response_body)}"
        )

    @staticmethod
    def make_request(
            base_url: str,
            endpoint: str,
            method: str,
            headers: Dict[str, str],
            auth: Optional[tuple] = None,
            data: Optional[Dict] = None,
    ) -> Any:
        url = f"{base_url}{endpoint}"
        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=headers, auth=auth)
            elif method.upper() == "POST":
                response = requests.post(url, json=data, headers=headers, auth=auth)
            elif method.upper() == "PUT":
                response = requests.put(url, json=data, headers=headers, auth=auth)
            elif method.upper() == "DELETE":
                response = requests.delete(url, headers=headers, auth=auth)
            else:
                raise ValueError("Invalid HTTP method")

            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            error_message = ""
            if e.response is not None:
                try:
                    error_message = e.response.json()
                except ValueError:
                    error_message = e.response.text
            logger.error(f"Error making {method} request to {url}: {e}")
            logger.info(f"Response content: {error_message}")
            return None

