import boto3

from hugoutils.telemetry.logger import LogManager

logger = LogManager.get_logger(__name__)


class EKSUtil:
    def __init__(self,aws_profile : str,aws_region : str):
        self.__boto3_session = boto3.Session(profile_name=aws_profile, region_name=aws_region)
         
    def get_eks_oidc_issuer_url(self, eks_cluster_name :str) -> str:

        logger.info(f"Creating oidc issuer for eks-{eks_cluster_name}")
        eks = self.__boto3_session.client("eks")
        response = eks.describe_cluster(
            name=eks_cluster_name,
        )
        oidc_issuer = (
            response.get("cluster", {})
            .get("identity", {})
            .get("oidc", {})
            .get("issuer")
        )
        logger.info(f"Created oidc issuer for eks-{eks_cluster_name} successfully")
        return oidc_issuer
